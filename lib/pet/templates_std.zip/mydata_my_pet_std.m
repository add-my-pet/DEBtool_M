function [data, auxData, metaData, txtData, weights] = mydata_my_pet_std 

%% set metaData
metaData.phylum     = ''; 
metaData.class      = ''; 
metaData.order      = ''; 
metaData.family     = '';
metaData.species    = 'my_pet'; 
metaData.species_en = 'my_pet_english_name'; 
metaData.T_typical  = C2K(20); % K, body temp
metaData.data_0     = {}; 
metaData.data_1     = {}; 

metaData.COMPLETE = ; % using criteria of LikaKear2011

metaData.author   = {};    
metaData.date_subm = [];              
metaData.email    = {};            
metaData.address  = {};   

%% set data
% zero-variate data

data.ab = ;    units.ab = 'd';    label.ab = 'age at birth';             bibkey.ab = '';   
  temp.ab = C2K();  units.temp.ab = 'K'; label.temp.ab = 'temperature';
data.ap = ;    units.ap = 'd';    label.ap = 'age at puberty';           bibkey.ap = '';
  temp.ap = C2K();  units.temp.ap = 'K'; label.temp.ap = 'temperature';
data.am = ;    units.am = 'd';    label.am = 'life span';                bibkey.am = '';   
  temp.am = C2K();  units.temp.am = 'K'; label.temp.am = 'temperature'; 

data.Lb  = ;   units.Lb  = 'cm';  label.Lb  = 'total length at birth';   bibkey.Lb  = '';  
data.Lp  = ;   units.Lp  = 'cm';  label.Lp  = 'total length at puberty'; bibkey.Lp  = ''; 
data.Li  = ;   units.Li  = 'cm';  label.Li  = 'ultimate total length';   bibkey.Li  = '';

data.Wwb = ;   units.Wwb = 'g';   label.Wwb = 'wet weight at birth';     bibkey.Wwb = '';
data.Wwp = ;   units.Wwp = 'g';   label.Wwp = 'wet weight at puberty';   bibkey.Wwp = '';
data.Wwi = ;   units.Wwi = 'g';   label.Wwi = 'ultimate wet weight';     bibkey.Wwi = '';

data.Ri  = ;   units.Ri  = '#/d'; label.Ri  = 'maximum reprod rate';     bibkey.Ri  = '';   
temp.Ri = C2K();    units.temp.Ri = 'K'; label.temp.Ri = 'temperature';
 
% uni-variate data
% t-L data
data.tL = [ ...
    ]';  % cm, total length at f and T
units.tL   = {'d', 'cm'};  label.tL = {'time since birth', 'total length'};  
temp.tL    = C2K();  units.temp.tL = 'K'; label.temp.tL = 'temperature';
bibkey.tL = '';
  
% L-W data
data.LW = [ ... % total length (cm), wet weight (g) 
    ]';   
units.LW = {'cm', 'g'};     label.LW = {'total length', 'wet weight'};  
bibkey.LW = '';

%% set weights for all real data
weights = setweights(data, []);

%% set pseudodata and respective weights
[data, units, label, weights] = addpseudodata(data, units, label, weights);

%% pack auxData and txtData for output
auxData.temp = temp;
txtData.units = units;
txtData.label = label;
txtData.bibkey = bibkey;
txtData.comment = comment;

%% Group plots
set1 = {''}; comment1 = {''};
metaData.grp.sets = {set1};
metaData.grp.comment = {comment1};

%% Discussion points
D1 = '';
D2 = '';     
metaData.discussion = struct('D1', D1, 'D2', D2);

%% Facts
F1 = '';
metaData.bibkey.F1 = ''; 
metaData.facts = struct('F1',F1);

%% References
bibkey = 'Wiki'; type = 'Misc'; bib = ...
'howpublished = {\url{http://en.wikipedia.org/wiki/my_pet}}';
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Kooy2010'; type = 'Book'; bib = [ ...  % used in setting of chemical parameters and pseudodata
'author = {Kooijman, S.A.L.M.}, ' ...
'year = {2010}, ' ...
'title  = {Dynamic Energy Budget theory for metabolic organisation}, ' ...
'publisher = {Cambridge Univ. Press, Cambridge}, ' ...
'pages = {Table 4.2 (page 150), 8.1 (page 300)}, ' ...
'howpublished = {\url{http://www.bio.vu.nl/thb/research/bib/Kooy2010.html}}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = ''; type = 'Article'; bib = [ ... 
'author = {}, ' ... 
'year = {}, ' ...
'title = {}, ' ...
'journal = {}, ' ...
'volume = {}, ' ...
'number = {}, '...
'pages = {}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];

